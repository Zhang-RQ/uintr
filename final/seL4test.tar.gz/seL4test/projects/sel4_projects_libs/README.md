<!--
     Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)

     SPDX-License-Identifier: CC-BY-SA-4.0
-->

# seL4\_projects\_libs

## seL4 Projects Libraries

A collection of libraries for seL4. These libraries are compatible with seL4_libs.

## Contributing

Contributions welcome!

See the [CONTRIBUTING](.github/CONTRIBUTING.md) file for more.
