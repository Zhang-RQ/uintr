/*
 * Copyright 2019, DornerWorks
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */

#define PLAT_CPU_COMPAT "arm,cortex-a53"
