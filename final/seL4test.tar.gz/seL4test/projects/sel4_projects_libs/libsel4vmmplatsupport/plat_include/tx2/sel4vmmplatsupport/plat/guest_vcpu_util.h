/*
 * Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */

#define PLAT_CPU_COMPAT "arm,cortex-a57-64bit\0arm,armv8"
