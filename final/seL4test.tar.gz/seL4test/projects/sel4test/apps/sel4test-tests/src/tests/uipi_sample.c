#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "../helpers.h"

#include "sel4/simple_types.h"
#include "uintr.h"

extern __inline
    unsigned long 
    __attribute__((__gnu_inline__, __always_inline__, __artificial__))
rdcycle(void)
{
    unsigned long dst;
    // output into any register, likely a0
    // regular instruction:
    asm volatile ("csrrs %0, 0xc00, x0" : "=r" (dst) );
    // regular instruction with symbolic csr and register names
    // asm volatile ("csrrs %0, cycle, zero" : "=r" (dst) );
    // pseudo-instruction:
    // asm volatile ("csrr %0, cycle" : "=r" (dst) );
    // pseudo-instruction:
    //asm volatile ("rdcycle %0" : "=r" (dst) );
    return dst;
}

volatile unsigned int uintr_received;
unsigned int uintr_fd;

uint64_t uintr_handler(struct __uintr_frame *ui_frame, uint64_t irqs) {
  // printf("\t-- User Interrupt handler --\n");

  // read pending bits
  // printf("\tPending User Interrupts: %lx\n", irqs);

  uintr_received = 1;

  return 0;
}

int uipi_index;

int sender_thread_init(seL4_Word arg1, seL4_Word arg2, seL4_Word arg3,
                       seL4_Word arg4) {
  // printf("In sender thread init\n");

  uipi_index = uintr_register_sender(0, 6);
  if (uipi_index < 0) {
    // printf("Sending IPI from sender thread\n");
    exit(EXIT_FAILURE);
  }


  return 0;
}

int receiver_thread_init(seL4_Word arg1, seL4_Word arg2, seL4_Word arg3,
                         seL4_Word arg4) {
  // printf("In receiver thread init\n");

  if (uintr_register_receiver(uintr_handler)) {
    // printf("Interrupt handler register error\n");
    exit(EXIT_FAILURE);
  }

  return 0;
}

int sender_thread(seL4_Word arg1, seL4_Word arg2, seL4_Word arg3,
                  seL4_Word arg4) {
  // printf("In sender thread\n");

  // printf("Sending IPI from sender thread\n");
  uipi_send(uipi_index);

  return 0;
}

int receiver_thread(seL4_Word arg1, seL4_Word arg2, seL4_Word arg3,
                    seL4_Word arg4) {
  // printf("In receiver thread\n");

  // printf("Waiting for IPI from sender thread\n");
  while (!uintr_received)
    seL4_Yield();

  // printf("Received IPI from sender thread\n");

  return 0;
}

int uipi_sample_main(env_t env) {
  printf("Basic test: uipi_sample\n");

  helper_thread_t sender, receiver;
  create_helper_thread(env, &sender);
  create_helper_thread(env, &receiver);
  start_helper(env, &sender, sender_thread_init, 0, 0, 0, 0);
  start_helper(env, &receiver, receiver_thread_init, 0, 0, 0, 0);
  wait_for_helper(&sender);
  wait_for_helper(&receiver);

  unsigned long a = rdcycle();
  start_helper(env, &sender, sender_thread, 0, 0, 0, 0);
  start_helper(env, &receiver, receiver_thread, 0, 0, 0, 0);
  wait_for_helper(&sender);
  wait_for_helper(&receiver);
  unsigned long b = rdcycle();

  printf("Success\n");
  printf("Cycles: %lu\n", b - a);
  return sel4test_get_result();
}
DEFINE_TEST(UIPI_SAMPLE, "UIPI_SAMPLE",
            uipi_sample_main, true)