#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "../helpers.h"

#include "sel4/simple_types.h"
#include "sel4/syscalls_master.h"
#include "sel4utils/process.h"
#include "vka/cspacepath_t.h"
#include "vka/object.h"
#include <vka/object_capops.h>

extern __inline
    unsigned long 
    __attribute__((__gnu_inline__, __always_inline__, __artificial__))
rdcycle(void)
{
    unsigned long dst;
    // output into any register, likely a0
    // regular instruction:
    asm volatile ("csrrs %0, 0xc00, x0" : "=r" (dst) );
    // regular instruction with symbolic csr and register names
    // asm volatile ("csrrs %0, cycle, zero" : "=r" (dst) );
    // pseudo-instruction:
    // asm volatile ("csrr %0, cycle" : "=r" (dst) );
    // pseudo-instruction:
    //asm volatile ("rdcycle %0" : "=r" (dst) );
    return dst;
}

typedef int (*test_func_t)(seL4_Word /* endpoint */, seL4_Word /* seed */, seL4_Word /* reply */,
                           seL4_CPtr /* extra */);

static int send_func(seL4_Word endpoint, seL4_Word endpoint1, seL4_Word reply, seL4_Word extra)
{
    seL4_Word sender_badge = 0;
    // printf("In sender thread\n");
    seL4_MessageInfo_t tag = seL4_MessageInfo_new(0, 0, 0, 1);
    seL4_SetMR(0, 233);

    seL4_NBSend(endpoint, tag);
    tag = seL4_Recv(endpoint1, &sender_badge);
    // printf("In sender thread End\n");
    return SUCCESS;
}

static int recv_func(seL4_Word endpoint, seL4_Word endpoint1, seL4_Word reply, seL4_Word extra)
{
    // printf("In receiver thread\n");
    seL4_Word sender_badge = 0;
    UNUSED seL4_MessageInfo_t tag;

    tag = seL4_Recv(endpoint, &sender_badge);
    tag = seL4_MessageInfo_new(0, 0, 0, 1);
    seL4_SetMR(0, 666);

    seL4_NBSend(endpoint1, tag);


    return SUCCESS;
}

int ipc_pingpong_main(env_t env) {
    printf("Start IPC test\n");
    int error;
    cspacepath_t ep_cap_path;

    seL4_CPtr ep = vka_alloc_endpoint_leaky(&env -> vka);
    seL4_CPtr ep1 = vka_alloc_endpoint_leaky(&env -> vka);
    ZF_LOGF_IFERR(error, "Failed to allocate new endpoint object.\n");
    printf("ep = %lu\n", ep);

    cspacepath_t path,path1;
    vka_cspace_make_path(&env -> vka, ep, &path);
    vka_cspace_make_path(&env -> vka, ep1, &path1);

    helper_thread_t sender, receiver;
    create_helper_process(env, &sender);
    create_helper_process(env, &receiver);
    seL4_Word thread_a_arg0 = sel4utils_copy_path_to_process(&sender.process, path);
    seL4_Word thread_b_arg0 = sel4utils_copy_path_to_process(&receiver.process, path);
    seL4_Word thread_a_arg1 = sel4utils_copy_path_to_process(&sender.process, path1);
    seL4_Word thread_b_arg1 = sel4utils_copy_path_to_process(&receiver.process, path1);

    
    unsigned long a = rdcycle();
    start_helper(env, &sender, send_func, thread_a_arg0, thread_a_arg1, 0, 0);
    start_helper(env, &receiver, recv_func, thread_b_arg0, thread_a_arg1, 0, 0);
    wait_for_helper(&sender);
    wait_for_helper(&receiver);
    unsigned long b = rdcycle();
  
    printf("Cycles: %lu\n", b - a);

    return sel4test_get_result();
}
DEFINE_TEST(IPC_PINGPONG, "IPC_PINGPONG",
            ipc_pingpong_main, true)