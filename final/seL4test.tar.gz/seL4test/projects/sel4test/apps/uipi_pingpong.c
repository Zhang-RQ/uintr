#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "../helpers.h"

#include "sel4/simple_types.h"
#include "uintr.h"

volatile unsigned int uintr_received_2[2];
volatile unsigned int uintr_receiver_id[2];
volatile unsigned int uintr_receiver_done[2];

#define MASTER_TOKEN 0
#define SLAVE_TOKEN 1

extern __inline
    unsigned long 
    __attribute__((__gnu_inline__, __always_inline__, __artificial__))
rdcycle(void)
{
    unsigned long dst;
    // output into any register, likely a0
    // regular instruction:
    asm volatile ("csrrs %0, 0xc00, x0" : "=r" (dst) );
    // regular instruction with symbolic csr and register names
    // asm volatile ("csrrs %0, cycle, zero" : "=r" (dst) );
    // pseudo-instruction:
    // asm volatile ("csrr %0, cycle" : "=r" (dst) );
    // pseudo-instruction:
    //asm volatile ("rdcycle %0" : "=r" (dst) );
    return dst;
}


uint64_t uintr_handler2(struct __uintr_frame *ui_frame, uint64_t irqs) {
  if(irqs == 0) {
    return 0;
  }
  // printf("\t-- User Interrupt handler --\n");

  // read pending bits
  // printf("\tPending User Interrupts: %lx\n", irqs);
  uint64_t tmp = irqs;
  int cnt = -1;
  while(tmp) {
    tmp >>= 1;
    cnt ++;
  }

  assert(cnt >= 0);

  uintr_received_2[cnt] = 1;

  return 0;
}

int master_thread_init_reciever(seL4_Word arg1, seL4_Word arg2, seL4_Word arg3,
                  seL4_Word arg4) {
  // printf("In Master thread Init Reciever\n");

  uintr_receiver_id[MASTER_TOKEN] = uintr_register_receiver(uintr_handler2);
  uintr_receiver_done[MASTER_TOKEN] = 1;

  // printf("Master Registed, id=%d\n", uintr_receiver_id[MASTER_TOKEN]);

  return 0;
}

int uipi_index;
int master_thread_init_sender(seL4_Word arg1, seL4_Word arg2, seL4_Word arg3,
                  seL4_Word arg4) {
  // printf("In Master thread Init Sender\n");


  uipi_index = uintr_register_sender(SLAVE_TOKEN, SLAVE_TOKEN);
  // puts("Master registered sender");
  if (uipi_index < 0) {
    printf("Failed IPI from Master thread\n");
    exit(EXIT_FAILURE);
  }

  return 0;
}

int slave_thread_init_reciever(seL4_Word arg1, seL4_Word arg2, seL4_Word arg3,
                  seL4_Word arg4) {
  // printf("In Slave thread Init Reciever\n");

  uintr_receiver_id[SLAVE_TOKEN] = uintr_register_receiver(uintr_handler2);
  uintr_receiver_done[SLAVE_TOKEN] = 1;

  // printf("Slave Registed, id=%d\n", uintr_receiver_id[SLAVE_TOKEN]);

  return 0;
}

int slave_thread_init_sender(seL4_Word arg1, seL4_Word arg2, seL4_Word arg3,
                  seL4_Word arg4) {
  // printf("In Slave thread Init Sender\n");


  uipi_index = uintr_register_sender(MASTER_TOKEN, MASTER_TOKEN);
  // puts("Slave registered sender");
  if (uipi_index < 0) {
    printf("Failed IPI from Slave thread\n");
    exit(EXIT_FAILURE);
  }

  return 0;
}

int master_thread(seL4_Word arg1, seL4_Word arg2, seL4_Word arg3,
                  seL4_Word arg4) {
  // printf("Sending IPI from Master thread\n");
  uipi_send(uipi_index);

  while(!uintr_received_2[MASTER_TOKEN]) {
    // puts("Waiting Master");
    seL4_Yield();
  }

  return 0;
}

int slave_thread(seL4_Word arg1, seL4_Word arg2, seL4_Word arg3,
                  seL4_Word arg4) {
  while(!uintr_received_2[SLAVE_TOKEN]) {
    // puts("Waiting Slave");
    seL4_Yield();
  }

  // printf("Sending IPI from slave thread\n");
  uipi_send(uipi_index);

  return 0;

}

int uipi_pingpong_main(env_t env) {
  printf("Basic test: uipi_pingpong\n");

  helper_thread_t master, slave;
  create_helper_thread(env, &master);
  create_helper_thread(env, &slave);
  start_helper(env, &master, master_thread_init_reciever, 0, 0, 0, 0);
  wait_for_helper(&master);
  start_helper(env, &slave, slave_thread_init_reciever, 0, 0, 0, 0);
  wait_for_helper(&slave);

  start_helper(env, &master, master_thread_init_sender, 0, 0, 0, 0);
  wait_for_helper(&master);
  start_helper(env, &slave, slave_thread_init_sender, 0, 0, 0, 0);
  wait_for_helper(&slave);

    unsigned long a = rdcycle();
  start_helper(env, &master, master_thread, 0, 0, 0, 0);
  start_helper(env, &slave, slave_thread, 0, 0, 0, 0);
  wait_for_helper(&slave);
  wait_for_helper(&master);
    unsigned long b = rdcycle();
  
    printf("Cycles: %lu\n", b - a);

  printf("Success\n");
  return sel4test_get_result();
}
DEFINE_TEST(UIPI_PINGPONG, "UIPI_PINGPONG",
            uipi_pingpong_main, true)